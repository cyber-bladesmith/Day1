/***************************************************************************
 * Program: PWDUMP4 - dump winnt/2000 user/password hash remote or local for crack
 * 
 * Copyright (c) 2002, 2003 bingle, all rights reserved
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Author:  bingle@email.com.cn
 * File:    PipeInOut.h
 * Purpose: pipe transfer module define 
 * Date:    2002-1-20
 * 
 ***************************************************************************/

#define		MESSAGE_PIPE	PIPE_READMODE_MESSAGE | PIPE_TYPE_MESSAGE
#define		BYTE_PIPE		PIPE_READMODE_BYTE | PIPE_TYPE_BYTE

typedef void (*ProcessOutType)( char *buff, int len );

typedef struct{
	unsigned long type;
	char *pipe;
	HANDLE *phPipe;
}BindParams;

typedef struct{
	char *ip;
	char *pipe;
	ProcessOutType func;
}ConnParams;

unsigned __stdcall thBindPipe( void *param );
int BindPipe( char *pipe, DWORD type, HANDLE *hPipe );

unsigned __stdcall thConnectPipe( void *param );
int ConnectPipe( char *ip, char *pipe, ProcessOutType func );

void EndBindPipe( HANDLE hPipe );

