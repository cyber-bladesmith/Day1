/***************************************************************************
 * Program: PWDUMP4 - dump winnt/2000 user/password hash remote or local for crack
 * 
 * Copyright (c) 2002, 2003 bingle, all rights reserved
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Author:  bingle@email.com.cn
 * File:    PwDump4.h
 * Purpose: PwDump4 general define
 * Date:    2002-1-20
 * 
 ***************************************************************************/

#include "Global.h"
#include "PipeInOut.h"

#define		DEFAULT_SHARE		"ADMIN$"
#define		DEFAULT_SERVICE		"pwservice"
#define		DEFAULT_DLLNAME		"pwdump4.dll"
#define		SERVICE_TAG			"/Svc:"

#define RUN_REMOTELY	1
#define RUN_LOCALLY		2

extern char exeName[MAX_PATH];

extern char *userName,
	*share,
	*outName,
	*target,
	newname[MAX_PATH];

extern bool bLocal,
	bRename;


int ProcessCmdLine( int argc, char *argv[] );
//bool CopyFileTo( char *fnExist, char *pathNew, char newFileName[] );

void __stdcall PWServiceMain( int argc, char* argv[] );
int PwDumpMain( int argc, char* argv[] );
int LocalDump( char *pipename );

DWORD GetLsassPid( );

//InjectRemote.cpp
HANDLE PrepareInject( char *pipe, int mode );
void InjectDll( HANDLE hProc, unsigned magic );
