/***************************************************************************
 * Program: PWDUMP4 - dump winnt/2000 user/password hash remote or local for crack
 * 
 * Copyright (c) 2002, 2003 bingle, all rights reserved
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Author:  bingle@email.com.cn
 * File:    Global.h
 * Purpose: some common functions define
 * Date:    2002-1-20
 * 
 ***************************************************************************/

#include <stdio.h>

#define		ERROR_NO_ERROR		0
#define		ERROR_LOAD_LSADLL	-1
#define		ERROR_LOAD_HASHFUNC	-2
#define		ERROR_INVALID_PARAM	-3
#define		ERROR_DUP_PIPE		-4
#define		ERROR_NO_CONNECT	-5
#define		ERROR_LOAD_SAMDLL	-6
#define		ERROR_LOAD_SAMFUNC	-7
#define		ERROR_OPEN_PROCESS	-8
#define		ERROR_LAST_ERROR    ERROR_OPEN_PROCESS	

#define		INVALID_HANDLE		INVALID_HANDLE_VALUE

#define		LSA_OUTPUT_TAG 		"LSA>"
#define		SRV_OUTPUT_TAG 		"SRV>"

DWORD SetDebugPrivilege();
int ExecuteMainName( char name[] );
void ExecuteMainName( char *exePath, char name[] );

void obfuscate( unsigned* data, unsigned magic, unsigned count );

#ifdef _DEBUG
void DebugOutput( char *lpFmt, ... );
#else
#define DebugOutput NULL
#endif
