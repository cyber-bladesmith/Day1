

[ Pwdump5 ]

Copyright (c) 2004 AntonYo!
All rights reserved.

-> Overview

Pwdump5 is an application that dumps NT password hashes from
SAM database even if Syskey is enabled on the system. If Syskey is
enabled program retrieves a 128-bit encryption key, which is used
to encrypt/decrypt password hashes.

-> Using Pwdump5

Usage: pwdump5.exe <data> [syskey] [option]

<data>
	-r [] : Gets data from the registry.
	-f <sam> [system] [security] : Gets data from the files.

[syskey]
	-l [] : Retrieves Syskey stored locally.
	-p [password] : Syskey is a password's MD5 digest.
	-k [key-file] : Reads Syskey from the key-file.

[option]
	-s [] : Displays SecureBoot mode.

Pwdump5 can dump hashes both from the registry (-r argument)
and from the configuration files (-f argument). If Syskey is
enabled you have to know it to decrypt hashes. Using -s option
you can find out where it is stored or whether it is a
password's MD5 digest. If SecureBoot mode is 0x00 it means that
Syskey is disabled and you don't need to use the second argument.

0x01 : Syskey is stored locally. Use -l argument.
0x02 : Syskey is a password's MD5 digest. Use -p argument.
0x03 : Syskey is stored on floppy disk. Use -k argument.

Using System key programs retrieves a 128-bit encryption key,
which is used to encrypt/decrypt password hashes. Then the hashes
are decrypted with DES using user's RID (Relative ID) as a key.

The output follows the same format as previous versions of pwdump:
"username:RID:LMHash:NTHash:comments:homedir:"

To capture the output in a file, run, for example,
"pwdump5.exe -r -l > hashes.txt".

You may also use alt-characters when you specify a password.

"\x**" - hex.
"\***" - dec.
"\\" instead of "\".

For example:
"pwdump5.exe -r -p \xFB"
"pwdump5.exe -r -p \251"
"pwdump5.exe -r -p \\password\\"

-> Disclaimer

THIS SOFTWARE IS PROVIDED BY ANTONYO! "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.

-> Distribution

This software may be distributed freely in its original unmodified form.
The distribution has to include all files of its original distribution.
Distributors may not charge any money for it.

-> Contact

Questions? Comments? Suggestions? Bug reports? Don't hesitate to
contact.
